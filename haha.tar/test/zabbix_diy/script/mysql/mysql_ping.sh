#!/bin/bash
#获取本地数据库信息
source /usr/local/etc/zabbix_agentd.conf.d/zabbix_diy/script/conf_script/get_info.sh
MYSQL_USER=`get_dbinfo mysql_user`       #这里为在本地数据库授权的账户and密码哦

# 密码
MYSQL_PWD=`get_dbinfo mysql_passwd`

# 主机地址/IP
MYSQL_HOST=`get_dbinfo mysql_ip`

# 端口
MYSQL_PORT=`get_dbinfo mysql_port`

mysqladmin  -u$MYSQL_USER -p$MYSQL_PWD -P$MYSQL_PORT ping 2>/dev/null | grep -c alive
