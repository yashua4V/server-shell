#!/bin/bash

function helpu() {
	echo "Usage for normal:"
	echo "${0} [options] [port_num] [tcp_state]"
	echo "options:"
	echo "  -h  dispaly help information"
	echo "  -c  display the counts only, this option must be used with a tcp state"
	echo "port_num:"
	echo "  define the port number of LOCAL port, it must be in the range of 0-65535"
	echo "tcp_state:"
	echo "  it can be used as full name or in short, and ignored case"
	echo "  established  est"
	echo "  syn_sent     ss"
	echo "  syn_recv     sr"
	echo "  fin_wait1    fw1"
	echo "  fin_wait2    fw2"
	echo "  time_wait    tw"
	echo "  closed       cld"
	echo "  close_wait   cw"
	echo "  last_ack     la"
	echo "  listen       lsn"
	echo "  closing      cli"
	echo "  unknown      ukn"
	echo "Example:"
	echo "  ${0}"
	echo "  ${0} 443"
	echo "  ${0} 443 established"
	echo "  ${0} -c est"
	echo "  ${0} -c 3306 est"
}


declare -i arg_count=0

function port_set() {
	if [ "${port_val}" != "1" ]; then
		port_num="${1}"
		port_val=1
		arg_count=$(( $arg_count+1 ))
	fi
}

function tcp_state_set() {
	if [ "${tcp_state_val}" != "1" ]; then
		tcp_state="${state_tmp}"
		tcp_state_val=1
		arg_count=$(( $arg_count+2 ))
	fi
}



function arg_chk() {
	case ${1} in
		-*)
			if [[ ${1} =~ ^-.*h ]]; then
				helpu
				exit 0
			fi
			if [[ ${1} =~ ^-.*c ]]; then
				counts_only_in_run=1
			fi
			;;
		[0-9]*)
			if ! [[ ${1} =~ ^([0-9]|[1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$ ]]; then
				echo "${0}: invalid port number, the valid port number is in the range of 0-65535"
				exit 1
			else
				port_set ${*}
			fi
			;;
		[eE][sS][tT][aA][bB][lL][iI][sS][hH][eE][dD]|[eE][sS][tT])
			state_tmp=ESTABLISHED
			tcp_state_set ${*}
			;;
		[sS][yY][nN]_[sS][eE][nN][tT]|[sS][sS])
			state_tmp=SYN_SENT
			tcp_state_set ${*}
			;;
		[sS][yY][nN]_[rR][eE][cC][vV]|[sS][rR])
			state_tmp=SYN_RECV
			tcp_state_set ${*}
			;;
		[fF][iI][nN]_[wW][aA][iI][tT]1|[fF][wW]1)
			state_tmp=FIN_WAIT1
			tcp_state_set ${*}
			;;
		[fF][iI][nN]_[wW][aA][iI][tT]2|[fF][wW]2)
			state_tmp=FIN_WAIT2
			tcp_state_set ${*}
			;;
		[tT][iI][mM][eE]_[wW][aA][iI][tT]|[tT][wW])
			state_tmp=TIME_WAIT
			tcp_state_set ${*}
			;;
		[cC][lL][oO][sS][eE][dD]|[cC][lL][dD])
			state_tmp=CLOSED
			tcp_state_set ${*}
			;;
		[cC][lL][oO][sS][eE]_[wW][aA][iI][tT]|[cC][wW])
			state_tmp=CLOSE_WAIT
			tcp_state_set ${*}
			;;
		[lL][aA][sS][tT]_[aA][cC][kK]|[lL][aA])
			state_tmp=LAST_ACK
			tcp_state_set ${*}
			;;
		[lL][iI][sS][tT][eE][nN]|[lL][sS][nN])
			state_tmp=LISTEN
			tcp_state_set ${*}
			;;
		[cC][lL][oO][sS][iI][nN][gG]|[cC][lL][iI])
			state_tmp=CLOSING
			tcp_state_set ${*}
			;;
		[uU][nN][kK][nN][oO][wW][nN]|[uU][kK][nN])
			state_tmp=UNKNOWN
			tcp_state_set ${*}
			;;
		*)
			;;
	esac
}


while (( ${#} != 0 ))
do
	arg_chk ${*}
	shift
done

if (( ${arg_count} == 0 )); then
	condition="| awk '"'$1~/tcp/{print $6}'"'" 
fi

if (( ${arg_count} == 1 )); then
	condition="| awk '"'$4~/.*:'"${port_num}"'/{print $6}'"'" 
fi

if (( ${arg_count} == 2 )); then
	condition="| awk '"'$6~/'"${tcp_state}"'/{print $6}'"'"
fi

if (( ${arg_count} == 3 )); then
	condition="| awk '"'$4~/.*:'"${port_num}"'/ && $6~/'"${tcp_state}"'/{print $6}'"'"
fi

if [[ "${counts_only_in_run}" == "1" ]]; then
	if [ -z "${tcp_state}" ]; then
		echo "the option -c must be used with a tcp state"
		helpu
		exit 1
	fi
	counts_only="| awk '{print "'$1'"}'"
	counts_only_result=$(echo 'netstat -tan '"${condition}"' | sort | uniq -c '"${counts_only}" | sh)
	if [ -z "${counts_only_result}" ]; then
		counts_only_result=0
	fi
	echo ${counts_only_result}
	exit 0
fi

echo 'netstat -tan '"${condition}"' | sort | uniq -c ' | sh

exit 0
