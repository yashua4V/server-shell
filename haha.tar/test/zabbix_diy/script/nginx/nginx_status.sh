#!/bin/bash
#匹配
case $1 in
#当前与http建立的连接数，包括等待的客户端连接
 'Active')
	curl -s http://127.0.0.1/nginx_status |grep Active |awk -F':' '{print $2}'
;;
#接受的客户端连接总数目
 'accepts')
	curl -s http://127.0.0.1/nginx_status | awk 'NR==3' |awk -F ' ' '{print $1}'
;;
#处理的客户端连接总数目
 'handled')
	curl -s http://127.0.0.1/nginx_status | awk 'NR==3' |awk -F ' ' '{print $2}'
;;
#客户端总的请求数目
 'requests')
	curl -s http://127.0.0.1/nginx_status | awk 'NR==3' |awk -F ' ' '{print $3}'
;;
#当前，nginx读请求连接
 'Reading')
	curl -s http://127.0.0.1/nginx_status |awk 'NR==4' |awk -F ' ' '{print $2}'
;;
#当前，nginx写响应返回给客户端
 'Writing')
	curl -s http://127.0.0.1/nginx_status |awk 'NR==4' |awk -F ' ' '{print $4}'
;;
#目前有多少空闲客户端请求连接
 'Waiting')
	curl -s http://127.0.0.1/nginx_status |awk 'NR==4' |awk -F ' ' '{print $6}'
;;
esac
