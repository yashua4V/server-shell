#!/bin/bash
function get_dbinfo(){
        conf_path="/usr/local/etc/zabbix_agentd.conf.d/zabbix_diy/localhost.conf/db.conf"
        find_row=`grep $1 $conf_path`
        echo ${find_row##*=}
}
